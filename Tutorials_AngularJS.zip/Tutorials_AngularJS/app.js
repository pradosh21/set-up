var app = angular.module("weatherApp", ["ngRoute", "ngResource"]);
app.config(function ($routeProvider,$locationProvider) {
    $routeProvider
        .when('/', {
            templateUrl: "pages/home.html",
            controller: "homeController"
        })
        .when('/features', {
            templateUrl: "pages/features.html",
            controller: "featuresController"
        })
        .when('/pricing', {
            templateUrl: "pages/pricing.html",
            controller: "pricingController"
        })
        $locationProvider.html5Mode({
            enabled:true,requireBase:true})

})
app.controller("homeController", ["$scope", "$http", "$resource", function ($scope, $http, $resource) {
    $scope.event = [];
    $scope.submitForm = function (form) {
        $scope.event.push(angular.copy(form));
        console.log($scope.event);
    }
}]);
app.controller("featuresController",["$scope","$http","$location",function($scope,$http,$location){
    console.log("abc");
}]);
app.controller("pricingController",["$scope","$http","$location",function($scope,$http,$location){
    console.log("xyz");
}]);